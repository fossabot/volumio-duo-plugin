#include <stdio.h>
#include <string.h>
#include "src/unity.h"
#include "util.h"

const char *SECTION = "\0";
const char *EMPTY_STR = "";
const char *NULL_STR = "\0";
